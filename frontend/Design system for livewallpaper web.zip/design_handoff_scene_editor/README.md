# Handoff: LiveWallpaper Scene Editor — Design System ("Zinc" direction)

## Overview
This package specifies a unified, component-library-based redesign of the LiveWallpaper **Scene Editor** (`frontend/src/ScenePage.tsx` and its children). The goal is to replace the current hand-rolled SCSS with a proper design system so future features can be added quickly and the UI can grow into a dense, Photoshop-style editor without becoming inconsistent.

The chosen direction is **"Zinc"** (option `2a` in the prototype): a shadcn/ui-style token system, Lucide icons, floating rounded panel cards, an indigo accent, and Figma-level density. It also includes an **"All conditions" modal** (option `2b`) that replaces the current always-expanded per-sprite conditions sidebar.

## Recommended stack
Implement in the **existing React + TypeScript frontend** (`frontend/`). Adopt:

- **shadcn/ui** — copy-in components built on **Radix UI primitives** + **Tailwind CSS**. Gives you accessible `DropdownMenu`, `Popover`, `Dialog`, `Slider`, `Tabs`, `Tooltip`, `ContextMenu`, `Command` (command palette) — all of which this editor needs as it grows.
- **Tailwind CSS** for the token layer (CSS variables → utility classes). Replaces the per-component `.scss` files.
- **lucide-react** for icons — **already a dependency** (`SpritePanelControl.tsx` imports `Link2`/`Unlink2`). Removes the current emoji icons (👁️ 🚫 📱 🖱).

Rationale: the repo already uses lucide-react, so this is the lowest-friction path; Radix's primitives replace bespoke popover/confirm/menu code (e.g. the click-outside logic in `SpriteListPanel.tsx`); and the CSS-variable token model scales cleanly to a denser GUI later.

## About the Design Files
`Scene Editor Directions.dc.html` in this bundle is a **design reference created in HTML** — a prototype showing the intended look and behavior, **not production code to copy directly**. It uses inline styles and static markup to communicate layout, color, type, spacing, and states. Your task is to **recreate these designs in the existing `frontend/` React codebase** using shadcn/ui + Tailwind components and the app's existing data/handlers (the `ScenePage` / `useSceneRenderer` wiring already exists and should be preserved).

Ignore the `.dc.html` wrapper mechanics and the "design canvas" scaffolding — only the editor mockups matter. The relevant options are the sections labeled **`2a`** (main editor) and **`2b`** (all-conditions modal). Options `1a`–`1d` are earlier exploration; `1a` is a faithful recreation of the *current* UI, useful only as a before/after reference.

## Fidelity
**High-fidelity.** Colors, typography, spacing, radii, and states below are final. Recreate pixel-closely, but use real shadcn/ui components rather than reproducing the inline-styled divs literally.

---

## Design Tokens

Define these as CSS variables (Tailwind theme extension). Dark-only.

### Color — surfaces (zinc ramp)
| Token | Hex | Use |
|---|---|---|
| `bg` (app) | `#09090b` | Editor background / canvas gutter |
| `panel` | `#131316` | Panel cards, top bar, modal body |
| `panel-inset` | `#0e0e11` | Canvas viewport well |
| `elevated` | `#17171c` | Active/expanded card header, hovered surfaces |
| `input` | `#1c1c21` | Inputs, segmented-control track, number fields |
| `hover` | `#1a1a1f` | Row hover |
| `selected` | `#22242f` | Selected sprite row |

### Color — borders
| Token | Hex | Use |
|---|---|---|
| `border` | `#232327` | Panel/card borders |
| `border-strong` | `#2b2b31` | Input borders, modal border |
| `border-subtle` | `#1e1e22` | Internal section dividers |

### Color — text
| Token | Hex | Use |
|---|---|---|
| `fg` | `#fafafa` | Primary / selected labels |
| `fg-default` | `#e4e4e7` | Body labels |
| `fg-muted` | `#d4d4d8` | Values in inputs |
| `fg-subtle` | `#8b8b93` | Axis labels, secondary |
| `fg-faint` | `#71717a` | Section headings, icons |
| `fg-faintest` | `#5b5b63` | Placeholder / "no checks" |

### Color — accent (indigo)
| Token | Hex | Use |
|---|---|---|
| `accent` | `#5b63e8` | Primary button, slider fill, selection bar |
| `accent-fg` | `#a5adff` | Accent text (badges, active tab) |
| `accent-bright` | `#7c86ff` | Active condition dot |
| `accent-bg` | `#1e2038` / `#252840` | Accent-tinted button / badge fill |
| `accent-border` | `#3c3f6e` | Accent-tinted borders |
| `accent-panel` | `#1a1c2c` | Active condition-set card body |
| `accent-panel-border` | `#2c2e46` | Dividers inside active condition card |
| `accent-input` | `#14151f` | Inputs inside active condition card |

### Color — semantic
| Token | Hex | Use |
|---|---|---|
| `success` | `#4ade80` | Save toast check icon |
| `danger` | `#e06c75` | Destructive menu items |

### Typography
- **Font family:** `Geist, system-ui, sans-serif` (Google Font "Geist"). Monospace only for the `.dc` explainer text — not needed in the app; use `font-variant-numeric: tabular-nums` on all numeric values instead.
- **Scale:** section headings `10px / 600 / uppercase / letter-spacing 0.08em / color fg-faint`; body & rows `12px`; values & axis labels `11px`; badges & meta `10px`; scene name `12.5px / 500`.

### Spacing / geometry
- Panel gaps: `10px` between top bar, panels, canvas (the editor shell has `10px` padding on all sides).
- Panel padding: `12px`. Row height: `28px` (list rows), `30–32px` (condition cards / modal rows). Top bar height: `44px`.
- **Radius:** panel cards `12px`; modal `14px`; buttons / inputs / segmented controls `6–8px`; badges & inner chips `5px`; sprite thumbnails `5px`.
- **Shadow (panel cards):** `0 4px 16px rgba(0,0,0,0.35)`. Modal: `0 24px 64px rgba(0,0,0,0.6)`. Toast/popover: `0 8px 24px rgba(0,0,0,0.5)`.
- Left panel width `248px`; right panel width `264px`; both `flex-shrink:0`, canvas `flex:1`.

---

## Screens / Views

### 1. Scene Editor (option `2a`)
Replaces the current 3-column `.app-content` layout in `ScenePage.tsx`. Shell is a flex column with `10px` padding; a top-bar card, then a flex row of **left panel · canvas · right panel**, all as **floating rounded cards** (`panel` bg, `border`, `12px` radius, panel shadow) separated by `10px` gaps.

**Top bar** (replaces `TopBar.tsx`, height 44px, `panel` card):
- Left: back chevron icon-button (`ChevronLeft`) → scene name button with `ChevronDown` (scene switcher dropdown — use Radix `DropdownMenu`) → vertical divider → **Images** button (`ImageIcon`, outline style) → **Guide** toggle (`Smartphone`, accent-tinted when on).
- Segmented control **Portrait / Landscape** (Radix or a styled 2-button group; track `input` bg, active pill `#2e2e36` / `fg`, inactive `fg-faint`).
- Segmented control **Pointer / Gyro** (icons `MousePointer2` / `Radar`), same treatment.
- Right (margin-left auto): zoom group `[−] 100% [＋] [Center]` in a bordered `input`-bg cluster (icons `Minus`, `Plus`, `Maximize`/`Scan`); scene-size label (`2.4 MB`, `fg-faint`, tooltip shows image/JSON breakdown); **Save** primary button (`accent` bg, white text, `Save` icon).

**Left panel** (248px) — three stacked sections divided by `border-subtle` lines:
- **SCENE** heading + a single slider row: `X Focus` label (44px) · track · number field (44px). Slider: 4px track, `input` bg, `accent` fill, 12px round white thumb with shadow. (Axis is X in portrait, Y in landscape — preserve the existing `orientation` logic from `SceneEditorPanel.tsx`.)
- **SPRITES · 5** heading with a `Plus` icon-button on the right. Then the sprite list — rows are 28px, `7px` radius, with: eye toggle (`Eye` / `EyeOff` from Lucide — replaces 👁️/🚫; hidden sprite row at `opacity:0.5`), a 16–18px checkerboard texture-thumbnail chip, the sprite name (`12px`, `500`+`fg` when selected), and a right-aligned parallax badge (e.g. `0.8×`, `10px`, in a `1f1f23` chip). Selected row: `selected` bg + `inset 2px 0 0 accent` left bar + a `MoreHorizontal` kebab (Radix `DropdownMenu`: Rename / Change Texture / Edit Texture / Conditions / **Delete** in danger red). Hover: `hover` bg.
- **Sprite inspector** — sprite name heading + active-condition badge (`Night`, accent chip). Then slider rows **X, Y, Z** (14px axis label · slider · 44px number field). Then the **W/H row** — this is a fix from the earlier version:

  **W/H row layout (important):** a 5-column grid `grid-template-columns: 14px 1fr 14px 1fr 22px; gap:6px; align-items:center`:
  `[W label] [width field] [H label] [height field] [link button]`.
  Both fields are `input` bg, right-aligned, tabular-nums. The link button (`Link2` when linked / `Unlink2` when unlinked) is 22px square; linked state uses `accent-bg` fill + `accent-border` + `accent-fg` icon. (This replaces the old absolutely-positioned aspect toggle that floated the "H" label into a weird spot — see `SpritePanelControl.scss` `.aspect-ratio-toggle`.)

**Canvas** (flex:1) — `panel-inset` bg, `border` `#1c1c21`, `12px` radius, `overflow:hidden`. Centered scene render (WebGL canvas mounts here — keep `#canvas-container` ref and all pointer/wheel/gyro handlers from `ScenePage.tsx`). Phone guide drawn as a `1.5px` `rgba(228,228,231,0.6)` rounded-rect (18px radius) overlay.

**Right panel** (264px) — **Conditions for the selected sprite only** (this is the key UX change; see below):
- Heading row: **CONDITIONS** + an **"All sprites"** button (`Grid`/`LayoutGrid` icon, outline, 22px tall) that opens the modal in screen 2.
- Selected-sprite identity row: thumbnail chip + sprite name + "2 sets".
- Condition-set list: a **Default** row (dot + italic "Default" + "no checks") and each set as a rounded card. The **active/previewing** set is expanded inline: `accent-border` + `accent-panel` bg, header with `accent-bright` dot + name + "previewing" + close (`X`), then a body with a **Match ALL/ANY** segmented control and check rows (two Radix `Select`s: flag + comparison, e.g. `time_of_day` / `is night`) and a dashed **"+ Add check"** button.
- Footer: ghost **"+ Add condition set"** button.

Toast (bottom, offset left of the right panel): `#18181b` card, `success` check icon + "Scene saved". Keep `NotificationStack.tsx` behavior; restyle only.

### 2. All Conditions modal (option `2b`)
Opened by the "All sprites" button. Replaces the always-visible `AllConditionsPanel.tsx` sidebar so the editor's right rail stays scoped to the selected sprite. Use Radix `Dialog`.
- Backdrop `rgba(0,0,0,0.55)` over the (blurred, dimmed) editor.
- Modal: 560px wide, `max-height:600px`, `panel` bg, `border-strong`, `14px` radius, large shadow, flex column.
- Header: "All conditions" title + "5 sprites · 5 sets" meta + a search field (`Search` icon, "Search flags, sprites…") + close `X`.
- Body (scroll): one collapsible section per sprite (Radix `Collapsible` or Accordion). Collapsed rows show `ChevronRight` + thumbnail + name + "N sets"/"no sets" badge. Expanded sections (`elevated` header, `ChevronDown`) list that sprite's sets as 28px rows; the active/previewing set is highlighted `accent-panel` + `accent-border` and shows its flag summary + "previewing".
- Footer: hint text "Click a set to select its sprite and preview it on canvas" + a **Done** button. Clicking any set selects that sprite in the editor and closes the modal (reuse the existing `ensureSpriteSelected` + `handleSelectConditionSet` handlers in `ScenePage.tsx`).

---

## Interactions & Behavior
- **Sprite select:** click row → `onSpriteSelect(index)`; updates inspector + right conditions panel.
- **Eye toggle:** click eye icon → `onSpriteToggle(index)`; `stopPropagation` so it doesn't select.
- **Rename:** double-click name or kebab → Rename (inline text input; Enter commits, Esc cancels — preserve `SpriteListPanel.tsx` logic).
- **Kebab menu / delete confirm:** use Radix `DropdownMenu` + `AlertDialog` (replaces bespoke popover + `.sprite-confirm-dialog`).
- **Sliders (X/Y/Z/W/H/Focus):** drag + editable number field; existing `SliderRow.tsx` semantics — `onChangeStart` (pointer down / focus) → `onChange` (live) → `onCommit` (pointer up / blur) feed the undo history. Preserve exactly; only restyle.
- **Aspect link:** toggles linked W/H; preserve `SpritePanelControl.tsx` ratio-lock logic.
- **All conditions modal:** open from "All sprites"; clicking a set selects+previews and closes.
- **Match ALL/ANY**, **flag/type selects**, **add/remove check & set:** preserve `ConditionSetsPanel.tsx` / `AllConditionsPanel.tsx` handlers.
- **Zoom/pan/gyro/wheel:** unchanged — keep all `ScenePage.tsx` canvas event wiring.
- **Transitions:** hover/color transitions ~120–150ms; toast slide-in (existing `slideIn` keyframes, 0.2s).

## State Management
No new app state required — this is a restyle + one layout change (conditions move from a permanent sidebar to selected-sprite panel + modal). Add local UI state only: `allConditionsModalOpen: boolean` on `ScenePage`. Everything else (`selectedSprite`, `spriteEntries`, condition sets, undo history, dirty flag, orientation, zoom, gyro) already exists in `useSceneRenderer` / `ScenePage.tsx` and must be preserved.

## Assets
- **Icons:** lucide-react — `ChevronLeft, ChevronDown, ChevronRight, ImageIcon, Smartphone, MousePointer2, Radar, Minus, Plus, Maximize (or Scan), Save, Eye, EyeOff, MoreHorizontal, Link2, Unlink2, LayoutGrid, Search, X, CheckCircle`. No custom SVGs needed.
- **Font:** Geist (Google Fonts / `geist` npm package).
- **Textures / thumbnails:** real sprite thumbnails come from the scene data (`thumbnail_url`); the checkerboard chips in the mock are placeholders.

## Files
- `Scene Editor Directions.dc.html` — the design reference (this bundle). Look at options **`2a`** and **`2b`**.
- Current source to refactor (in the repo, for reference):
  - `frontend/src/ScenePage.tsx` — page shell + canvas wiring (preserve logic)
  - `frontend/src/controls/TopBar.tsx` — top bar
  - `frontend/src/controls/panels/SceneEditorPanel.tsx`, `SpriteListPanel.tsx`, `SpritePanelControl.tsx` — left panel
  - `frontend/src/controls/panels/AllConditionsPanel.tsx`, `ConditionSetsPanel.tsx` — conditions (→ becomes right panel + modal)
  - `frontend/src/components/SliderRow.tsx`, `Button.tsx` — restyle to token system
  - `frontend/src/styles/main.scss`, `frontend/src/components/Button.scss`, and the per-component `.scss` files — replaced by Tailwind + shadcn tokens
